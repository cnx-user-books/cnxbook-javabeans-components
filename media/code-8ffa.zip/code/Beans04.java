/*File Beans04.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed 
under JDK 1.1.3 or later.

The bean class named Beans03 broadcasts a PropertyChanged
event whenever a new value is assigned to one of the 
instance variables used to maintain the property values
regardless of whether the new value is different from, or
the same as the old value.

Upgrade that bean class to produce a new bean class that
will refrain from broadcasting a PropertyChanged event if
the new value is the same as the old value.

Provide a bean test program to demonstrate proper operation
of the new bean class.

The main purpose of this program is to illustrate the use 
of "bound" properties in Beans.

This is a "bean" class that satisfies the interface
requirements for beans using design patterns.

This bean class has two properties named theColor and 
theDate.

The current value of the property named theColor is stored
in the instance variable named myColor.

The current value of the property named theDate is stored
in the instance variable named myDate.  theDate is a
write-only property because it has a "set" method but does
not have a "get" method.

The program maintains a list of objects that request to be 
notified whenever there is a change in the value of either
of the properties.  Whenever the value of either property
changes, all of the objects on the list are notified of the
change by invoking their propertyChange() method and 
passing an object of type PropertyChangeEvent as a 
parameter.

Objects that request to be added to the list must be of a
class that implements the PropertyChangeListener interface
and defines the propertyChange() method that is declared 
in that interface.

The PropertyChangeEvent object passed as a parameter to the
propertyChange() method in the listener objects contains 
the following information:
  
  Object source, //the bean object
  String propertyName, //the name of the changed property
  Object oldValue, //the old value of the changed property
  Object newValue  //the new value of the changed property
  
This program doesn't save the old value and therefore
passes null as the old value of the changed property 
because the old value is not available when the listener
objects are notified.
  
The following methods are available to extract information
from the object passed as a parameter.  These methods are
defined by the PropertyChangeEvent class or its superclass
named EventObject:
  
  public Object getSource();
  public Object getNewValue();
  public Object getOldValue();
  public String getPropertyName;
  public void setPropagationId();
  public Object getPropagationId;
  
Apparently the PropagationID is reserved for future use.  
    
The program was compiled and tested under JDK 1.1.3
and Win95.  Another program named Beans03Test.java was 
used to test the bean.  It was not tested in the BeanBox.
//=======================================================//
*/

import java.awt.event.*;
import java.awt.*;
import java.io.Serializable;
import java.util.*;
import java.beans.*;
//=======================================================//
//All beans should implement the Serializable interface
public class Beans04 extends Canvas 
                                   implements Serializable{

  //The following instance variables are used to store
  // property values.
  protected Color myColor;
  protected Date myDate;
  
  //The following vector is used to maintain a list of 
  // listeners who request to be notified of changes in the
  // property values.
  protected Vector propChangeListeners = new Vector();
  //-----------------------------------------------------//
  
  public Beans04(){//constructor
    //This bean is a visible square that is initialized to
    // yellow and can then be changed to green, red, and
    // blue by invoking methods of the class.
    myColor = Color.yellow;
    setBackground(myColor);
  }//end constructor
  //-----------------------------------------------------//

  //This method defines the preferred display size of the 
  // bean object.  
  public synchronized Dimension getPreferredSize(){
    return new Dimension(50,50);
  }//end getPreferredSize()
  //-----------------------------------------------------//

  //The following "set" and "get" methods in conjunction 
  // with the instance variable named myColor constitute a
  // property named theColor.  
  public synchronized void setTheColor(Color inColor){
    Color oldColor = myColor;
    myColor = inColor;
    this.setBackground(myColor);
    //notify property listeners of property change
    if(!myColor.equals(oldColor))
      notifyPropertyChange("theColor");
  }//end setTheColor()

  public synchronized Color getTheColor(){
    return myColor;
  }//end getTheColor
  //-----------------------------------------------------//
  
  //The following "set" method in conjunction with the 
  // instance variable named myDate constitute a write-only
  // property named theDate.
  public synchronized void setTheDate(Date dateIn){
    Date oldDate = myDate;
    myDate = dateIn;
    //notify property listeners of property change
    if(!myDate.equals(oldDate))
      notifyPropertyChange("theDate");
  }//end setTheDate()
  //-----------------------------------------------------//

  //The following two methods are exposed to the builder 
  // tool as accessible methods.  
  public synchronized void makeBlue(){
    Color oldColor = myColor;
    myColor = Color.blue;
    this.setBackground(myColor);
    //notify property listeners of property change
    if(!myColor.equals(oldColor))
      notifyPropertyChange("theColor");
  }//end makeBlue()

  public synchronized void makeRed(){
    Color oldColor = myColor;
    myColor = Color.red;
    this.setBackground(myColor);
    //notify property listeners of property change
    if(!myColor.equals(oldColor))
      notifyPropertyChange("theColor");
  }//end makeRed()
  //-----------------------------------------------------//
    
  //The following two methods are used to maintain a list
  // of listener objects who request to be notified of 
  // changes to the properties or who request to be removed
  // from the list.
  
  //Add a property change listener object to the list.
  public synchronized void addPropertyChangeListener(
                          PropertyChangeListener listener){
    //If the listener is not already registered, add it
    // to the list.
    if(!propChangeListeners.contains(listener)){
      propChangeListeners.addElement(listener);
    }//end if
  }//end addPropertyChangeListener
  
  //Remove a property change listener from the list.
  public synchronized void removePropertyChangeListener(
                          PropertyChangeListener listener){
    //If the listener is on the list, remove it
    if(propChangeListeners.contains(listener)){
      propChangeListeners.removeElement(listener);
    }//end if
  }//end removePropertyChangeListener
  //-----------------------------------------------------//
  
  //The following method is used to notify listener 
  // objects of changes in the properties.  The incoming
  // parameter is the name of the property that has 
  // changed.
  protected void notifyPropertyChange(
                                   String changedProperty){
    //Instantiate the event object containing information
    // about the property that has changed.
    PropertyChangeEvent event;
    if(changedProperty.compareTo("theColor") == 0)
      //Change was in theColor property
      event = new PropertyChangeEvent(
                        this,changedProperty,null,myColor);
    else//Change was in the theDate property
      event = new PropertyChangeEvent(
                         this,changedProperty,null,myDate);
    
    //Make a working copy of the list that cannot be 
    // modified while objects on the list are being 
    // notified of the change.
    Vector tempList;
    synchronized(this){
      tempList = (Vector)propChangeListeners.clone();
    }//end synchronized block
    
    //Notify all listener objects on the list.  Note the
    // requirement to cast the objects in the list from
    // Object to PropertyChangeListener.
    for(int cnt = 0; cnt < tempList.size();cnt++){
      PropertyChangeListener theListener = 
           (PropertyChangeListener)tempList.elementAt(cnt);
      //Invoke the propertyChange() method on theListener
      theListener.propertyChange(event);
    }//end for loop
  }//end notifyPropertyChange
}//end class Beans04.java
//=======================================================//