/*File Beans05.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed 
under JDK 1.1.3 or later.

This bean class is designed to replicate the functionality
of the bean class named Beans04 by making use of the 
support class named java.beans.PropertyChangeSupport to 
reduce the level of programming effort required.

This support class provides  methods for maintaining
the list of registered PropertyChange listeners and for
firing events to all of the listener objects on that list,
thus eliminating the need to code those capabilities by
hand as was done with Beans04.

The support class can either be extended or instantiated.
In this case, because this bean class was already
extending the Canvas class and multiple inheritance is
not allowed, the support class was instantiated.  This
made it necessary to do a little extra work in providing
bean interface methods to add and remove listener objects
and then to call the corresponding methods in the support
class object passing the listener references as parameters.
//=======================================================//
*/

import java.awt.event.*;
import java.awt.*;
import java.io.Serializable;
import java.util.*;
import java.beans.*;
//=======================================================//
//All beans should implement the Serializable interface
public class Beans05 extends Canvas 
                                   implements Serializable{

  //The following instance variables are used to store
  // property values.
  protected Color myColor;
  protected Date myDate;
  
  //The following reference variable is used to access
  // the list maintenance and event firing capabilities
  // of the PropertyChangeSupport class, an object of
  // which is instantiated in the constructor.  
  PropertyChangeSupport supportObj;
  //-----------------------------------------------------//
  
  public Beans05(){//constructor
    //This bean is a visible square that is initialized to
    // yellow and can then be changed to green, red, and
    // blue by invoking methods of the class.
    myColor = Color.yellow;
    setBackground(myColor);
    
    //Instantiate an object of the support class to handle
    // list maintenance and event firing tasks.  The
    // constructor requires this object as the source of
    // the events.
    supportObj = new PropertyChangeSupport(this);
 
  }//end constructor
  //-----------------------------------------------------//

  //This method defines the preferred display size of the 
  // bean object.  
  public synchronized Dimension getPreferredSize(){
    return new Dimension(50,50);
  }//end getPreferredSize()
  //-----------------------------------------------------//

  //The following "set" and "get" methods in conjunction 
  // with the instance variable named myColor constitute a
  // property named theColor.  
  public synchronized void setTheColor(Color inColor){
    Color oldColor = myColor;
    myColor = inColor;
    this.setBackground(myColor);
    //notify property listeners of property change
    if(!myColor.equals(oldColor))
      notifyPropertyChange("theColor");
  }//end setTheColor()

  public synchronized Color getTheColor(){
    return myColor;
  }//end getTheColor
  //-----------------------------------------------------//
  
  //The following "set" method in conjunction with the 
  // instance variable named myDate constitute a write-only
  // property named theDate.
  public synchronized void setTheDate(Date dateIn){
    Date oldDate = myDate;
    myDate = dateIn;
    //notify property listeners of property change
    if(!myDate.equals(oldDate))
      notifyPropertyChange("theDate");
  }//end setTheDate()
  //-----------------------------------------------------//

  //The following two methods are exposed to the builder 
  // tool as accessible methods.  
  public synchronized void makeBlue(){
    Color oldColor = myColor;
    myColor = Color.blue;
    this.setBackground(myColor);
    //notify property listeners of property change
    if(!myColor.equals(oldColor))
      notifyPropertyChange("theColor");
  }//end makeBlue()

  public synchronized void makeRed(){
    Color oldColor = myColor;
    myColor = Color.red;
    this.setBackground(myColor);
    //notify property listeners of property change
    if(!myColor.equals(oldColor))
      notifyPropertyChange("theColor");
  }//end makeRed()
  //-----------------------------------------------------//
    
  //The following two methods are used to maintain a list
  // of listener objects who request to be notified of 
  // changes to the properties or who request to be removed
  // from the list.  Note that these two methods do 
  // nothing more than to accept a reference to the
  // object requesting registration and pass that reference
  // to the list maintenance facility provided by an object
  // of the PropertyChangeSupport class.
  
  //Add a property change listener object to the list.
  public synchronized void addPropertyChangeListener(
                          PropertyChangeListener listener){
    supportObj.addPropertyChangeListener(listener);
  }//end addPropertyChangeListener

//-------------------------------------------------------//  

  //Remove a property change listener from the list.
  public synchronized void removePropertyChangeListener(
                          PropertyChangeListener listener){
    supportObj.removePropertyChangeListener(listener);
  }//end removePropertyChangeListener()
  //-----------------------------------------------------//
  
  //The following method is used to notify listener 
  // objects of changes in the properties.  The incoming
  // parameter is the name of the property that has 
  // changed.  Note that this method makes use of the 
  // event-firing capability of an object of the
  // PropertyChangeSupport class.
  protected void notifyPropertyChange(
                                   String changedProperty){
    if(changedProperty.compareTo("theColor") == 0)
      //Change was in theColor property
      supportObj.firePropertyChange(
                             changedProperty,null,myColor);
    else//Change was in the theDate property
      supportObj.firePropertyChange(
                              changedProperty,null,myDate);
  }//end notifyPropertyChange()
  
}//end class Beans05.java
//=======================================================//