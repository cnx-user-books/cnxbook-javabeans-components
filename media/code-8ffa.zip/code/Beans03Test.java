/*File Beans03Test.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed 
under JDK 1.1.3 or later.

The purpose of this program is to provide the ability to
test the bean class named Beans03.class in a Frame.

A Bean03 object is placed in the frame along with five 
buttons. 

The visual manifestation of the Bean object is a colored 
square.

Two of the buttons exercise the "get" and "set" methods
used to get and set the color value stored in the property
named theColor.

One button exercises the "set" method used to set the date
and time in a write-only property named theDate.

Two of the buttons invoke the makeRed() and makeBlue()
methods of the Bean which modify the value of the property
named theColor.

Two listener objects are instantiated and registered to
be notified by the bean whenever there is a change in the
value of either of the properties.  Actually the objects
are notified whenever a value is assigned to the instance
variables that maintain the property values regardless of
whether or not the new value is different from the old
value.

For those cases where information is returned from the 
Bean, it is displayed on the standard output device.

The program was tested using JDK 1.1.3 under Win95. 

Clicking the button labeled "Set theColor property" 
produced the following output on the screen.  As you can
see, the two different listener objects were notified of 
the same change in the property named theColor. In this 
case, the value of theColor property was changed to green.
  
FirstListener notified of change
Property change source: Beans03[canvas0,31,33,50x50]
Property name: theColor
New property value: java.awt.Color[r=0,g=255,b=0]
Old property value: null

SecondListener notified of change
Property change source: Beans03[canvas0,31,33,50x50]
Property name: theColor
New property value: java.awt.Color[r=0,g=255,b=0]
Old property value: null  
  

Clicking the button labeled "Get theColor property"
produced the following output on the screen.  Since 
this action didn't cause the property values to change, 
the listener objects were not notified of the action.

java.awt.Color[r=0,g=255,b=0]
  

Clicking the button labeled "Invoke the makeRed Method"
produced the following output on the screen. Again both
listener objects were notified of the change in the 
property named theColor with the new value being red.

FirstListener notified of change
Property change source: Beans03[canvas0,31,33,50x50]
Property name: theColor
New property value: java.awt.Color[r=255,g=0,b=0]
Old property value: null

SecondListener notified of change
Property change source: Beans03[canvas0,31,33,50x50]
Property name: theColor
New property value: java.awt.Color[r=255,g=0,b=0]
Old property value: null
  

Clicking the button labeled "Invoke the makeBlue Method"
produced the following output on the screen similar to
that produced by invoking the makeRed() method described
above.

FirstListener notified of change
Property change source: Beans03[canvas0,31,33,50x50]
Property name: theColor
New property value: java.awt.Color[r=0,g=0,b=255]
Old property value: null

SecondListener notified of change
Property change source: Beans03[canvas0,31,33,50x50]
Property name: theColor
New property value: java.awt.Color[r=0,g=0,b=255]
Old property value: null
  

Finally, clicking the button labeled "Set theDate 
property" produced the following output on the screen.
In this case, both listener objects were notified and
the information encapsulated in the event object 
identified the changed property as the property named
theDate with a new value as shown.

FirstListener notified of change
Property change source: Beans03[canvas0,31,33,50x50]
Property name: theDate
New property value: Sat Oct 18 10:24:49 CDT 1997
Old property value: null

SecondListener notified of change
Property change source: Beans03[canvas0,31,33,50x50]
Property name: theDate
New property value: Sat Oct 18 10:24:49 CDT 1997
Old property value: null
    
*/

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;
//=======================================================//
public class Beans03Test extends Frame{
  public static void main(String[] args){
    new Beans03Test();
  }//end main
  //-----------------------------------------------------//

  public Beans03Test(){//constructor
    setTitle("Copyright 1997, R.G.Baldwin");
    setLayout(new FlowLayout());
    //instantiate a Bean object
    Beans03 myBean = new Beans03();
    add(myBean);//Add it to the Frame
    
    //Instantiate several test buttons 
    Button buttonToSetTheColor = 
                       new Button("Set theColor property");
    Button buttonToGetTheColor = 
                       new Button("Get theColor property");
    Button buttonToInvokeRedMethod = 
                       new Button("Invoke makeRed Method");
    Button buttonToInvokeBlueMethod = 
                      new Button("Invoke makeBlue Method");
    Button buttonToSetTheDate = 
                        new Button("Set theDate property");
                      
    //Add the test buttons to the frame  
    add(buttonToSetTheColor);
    add(buttonToGetTheColor);
    add(buttonToInvokeRedMethod);
    add(buttonToInvokeBlueMethod);
    add(buttonToSetTheDate);
    
    //Size the frame and make it visible
    setSize(250,350);
    setVisible(true);

    //Register action listener objects for all the test 
    // buttons    
    buttonToSetTheColor.addActionListener(
                          new SetTheColorListener(myBean));
    buttonToGetTheColor.addActionListener(
                          new GetTheColorListener(myBean));
    buttonToInvokeRedMethod.addActionListener(
                            new RedActionListener(myBean));
    buttonToInvokeBlueMethod.addActionListener(
                           new BlueActionListener(myBean));
    buttonToSetTheDate.addActionListener(
                           new DateActionListener(myBean));
                           
    //Instantiate and register two PropertyChangeListener 
    // objects to listen for changes in the bean's 
    // properties.
    MyPropertyChangeListener firstListener = 
                            new MyPropertyChangeListener();
    //Store an identifying name in the listener object
    firstListener.setTheID("FirstListener");
    myBean.addPropertyChangeListener(firstListener);
                           
    MyPropertyChangeListener secondListener = 
                            new MyPropertyChangeListener();
    //Store an identifying name in the listener object
    secondListener.setTheID("SecondListener");
    myBean.addPropertyChangeListener(secondListener);
    
    //The following statements can be activated to confirm
    // proper operation of the removePropertyChangeListener
    // interface of the bean object.  When one or the other
    // of these statements is activated, and the program is
    // recompiled, only the other listener object is 
    // notified of changes in the values of properties 
    // in the bean.
//    myBean.removePropertyChangeListener(firstListener);
//    myBean.removePropertyChangeListener(secondListener);

    //terminate when Frame is closed    
    this.addWindowListener(new Terminate());
  }//end constructor
}//end class Beans03Test
//=======================================================//
//The following class is used to instantiate objects to 
// be registered to listen to one of the buttons on the 
// test panel.  When the setTheDate button is pressed, the 
// theDate property is set to the current date and time.
class DateActionListener implements ActionListener{
  Beans03 myBean;//save a reference to the bean here
  
  DateActionListener(Beans03 inBean){//constructor
    myBean = inBean;//save a reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    //Store the current date and time in the bean property
    // named theDate.
    myBean.setTheDate(new Date());
  }//end actionPerformed()
}//end class DateActionListener
//=======================================================//

//The following two classes are used to instantiate objects
// to be registered to listen to two of the buttons on the 
// test panel.  

// When the setTheColor button is pressed, the theColor 
// property is set to green. 

// When the getTheColor button is pressed, the current 
// color is displayed on the standard output device.

class SetTheColorListener implements ActionListener{
  Beans03 myBean;//save a reference to the bean here
  
  SetTheColorListener(Beans03 inBean){//constructor
    myBean = inBean;//save a reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.setTheColor(Color.green);
  }//end actionPerformed()
}//end class SetTheColorListener
//-------------------------------------------------------//

class GetTheColorListener implements ActionListener{
  Beans03 myBean;//save a reference to the bean here
  
  GetTheColorListener(Beans03 inBean){//constructor
    myBean = inBean;//save reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    //Display value of the theColor property on the
    // standard output device.
    System.out.println(myBean.getTheColor().toString());
  }//end actionPerformed()
}//end class GetTheColorListener

//=======================================================//
//The following two classes are used to instantiate objects
// to be registered to listen to two of the buttons on the 
// test panel.  When the corresponding the buttons are 
// pressed, these objects invoke methods of the bean under 
// test. The first class invokes the makeRed() method and
// the second class invokes the makeBlue() method.

class RedActionListener implements ActionListener{
  Beans03 myBean;//save a reference to the bean here
  
  RedActionListener(Beans03 inBean){//constructor
    myBean = inBean;//save the reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.makeRed();
  }//end actionPerformed()
}//end class RedActionListener
//-------------------------------------------------------//

class BlueActionListener implements ActionListener{
  Beans03 myBean;//save a reference to the bean here
  
  BlueActionListener(Beans03 inBean){//constructor
    myBean = inBean;//save the reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.makeBlue();
  }//end actionPerformed()
}//end class BlueActionListener
//=======================================================//

//The following class is used to instantiate objects that
// will be bound to the bean in such a way as to be 
// notified of changes in the property values in the bean 
// object.  When notified of such changes, code in the
// propertyChange() method of this class extracts and
// displays information about the bean and the properties.
class MyPropertyChangeListener 
                         implements PropertyChangeListener{
  String theID; //store listener object ID here
  
  void setTheID(String nameIn){
    //method to save the ID of the object
    theID = nameIn;
  }//end setTheID()
    
  public void propertyChange(PropertyChangeEvent event){
    //Extract and display information about the event
    System.out.println(theID + " notified of change");
    System.out.println("Property change source: " 
                                      + event.getSource());
    System.out.println("Property name: " 
                                + event.getPropertyName());
    System.out.println("New property value: " 
                                    + event.getNewValue());
    System.out.println("Old property value: " 
                                    + event.getOldValue());
    System.out.println();//blank line
  }//end propertyChange()
}//end MyPropertyChangeListener class
//=======================================================//

class Terminate extends WindowAdapter{
  public void windowClosing(WindowEvent e){
    //terminate the program when the window is closed  
    System.exit(0);
  }//end windowClosing
}//end class Terminate
//=======================================================//