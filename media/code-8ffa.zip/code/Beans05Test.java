/*File Beans05Test.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed 
under JDK 1.1.3 or later.

The purpose of this program is to provide the ability to
test the bean class named Beans05.class in a Frame.

See the comments in the file named Beans05.java to 
understand how this test program and the bean differ from 
the test program named Beans04Test and its corresponding 
bean.

Briefly, this pair of programs replicates the Beans04
pair in functionality.  However, Beans05 uses a support
class named java.beans.PropertyChangedSupport to reduce
the programming effort required for the bean.

See the program named Beans04Test for an operational 
description of this program along with sample output
produced by the program.
*/

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;
//=======================================================//
public class Beans05Test extends Frame{
  public static void main(String[] args){
    new Beans05Test();
  }//end main
  //-----------------------------------------------------//

  public Beans05Test(){//constructor
    setTitle("Copyright 1997, R.G.Baldwin");
    setLayout(new FlowLayout());
    //instantiate a Bean object
    Beans05 myBean = new Beans05();
    add(myBean);//Add it to the Frame
    
    //Instantiate several test buttons 
    Button buttonToSetTheColor = 
                       new Button("Set theColor property");
    Button buttonToGetTheColor = 
                       new Button("Get theColor property");
    Button buttonToInvokeRedMethod = 
                       new Button("Invoke makeRed Method");
    Button buttonToInvokeBlueMethod = 
                      new Button("Invoke makeBlue Method");
    Button buttonToSetTheDate = 
                        new Button("Set theDate property");
                      
    //Add the test buttons to the frame  
    add(buttonToSetTheColor);
    add(buttonToGetTheColor);
    add(buttonToInvokeRedMethod);
    add(buttonToInvokeBlueMethod);
    add(buttonToSetTheDate);
    
    //Size the frame and make it visible
    setSize(250,350);
    setVisible(true);

    //Register action listener objects for all the test 
    // buttons    
    buttonToSetTheColor.addActionListener(
                          new SetTheColorListener(myBean));
    buttonToGetTheColor.addActionListener(
                          new GetTheColorListener(myBean));
    buttonToInvokeRedMethod.addActionListener(
                            new RedActionListener(myBean));
    buttonToInvokeBlueMethod.addActionListener(
                           new BlueActionListener(myBean));
    buttonToSetTheDate.addActionListener(
                           new DateActionListener(myBean));
                           
    //Instantiate and register two PropertyChangeListener 
    // objects to listen for changes in the bean's 
    // properties.
    MyPropertyChangeListener firstListener = 
                            new MyPropertyChangeListener();
    //Store an identifying name in the listener object
    firstListener.setTheID("FirstListener");
    myBean.addPropertyChangeListener(firstListener);
                           
    MyPropertyChangeListener secondListener = 
                            new MyPropertyChangeListener();
    //Store an identifying name in the listener object
    secondListener.setTheID("SecondListener");
    myBean.addPropertyChangeListener(secondListener);
    
    //The following statements can be activated to confirm
    // proper operation of the removePropertyChangeListener
    // interface of the bean object.  When one or the other
    // of these statements is activated, and the program is
    // recompiled, only the other listener object is 
    // notified of changes in the values of properties 
    // in the bean.
//    myBean.removePropertyChangeListener(firstListener);
//    myBean.removePropertyChangeListener(secondListener);

    //terminate when Frame is closed    
    this.addWindowListener(new Terminate());
  }//end constructor
}//end class Beans05Test
//=======================================================//
//The following class is used to instantiate objects to 
// be registered to listen to one of the buttons on the 
// test panel.  When the setTheDate button is pressed, the 
// theDate property is set to the current date and time.
class DateActionListener implements ActionListener{
  Beans05 myBean;//save a reference to the bean here
  
  DateActionListener(Beans05 inBean){//constructor
    myBean = inBean;//save a reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    //Store the current date and time in the bean property
    // named theDate.
    myBean.setTheDate(new Date());
  }//end actionPerformed()
}//end class DateActionListener
//=======================================================//

//The following two classes are used to instantiate objects
// to be registered to listen to two of the buttons on the 
// test panel.  

// When the setTheColor button is pressed, the theColor 
// property is set to green. 

// When the getTheColor button is pressed, the current 
// color is displayed on the standard output device.

class SetTheColorListener implements ActionListener{
  Beans05 myBean;//save a reference to the bean here
  
  SetTheColorListener(Beans05 inBean){//constructor
    myBean = inBean;//save a reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.setTheColor(Color.green);
  }//end actionPerformed()
}//end class SetTheColorListener
//-------------------------------------------------------//

class GetTheColorListener implements ActionListener{
  Beans05 myBean;//save a reference to the bean here
  
  GetTheColorListener(Beans05 inBean){//constructor
    myBean = inBean;//save reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    //Display value of the theColor property on the
    // standard output device.
    System.out.println(myBean.getTheColor().toString());
  }//end actionPerformed()
}//end class GetTheColorListener

//=======================================================//
//The following two classes are used to instantiate objects
// to be registered to listen to two of the buttons on the 
// test panel.  When the corresponding the buttons are 
// pressed, these objects invoke methods of the bean under 
// test. The first class invokes the makeRed() method and
// the second class invokes the makeBlue() method.

class RedActionListener implements ActionListener{
  Beans05 myBean;//save a reference to the bean here
  
  RedActionListener(Beans05 inBean){//constructor
    myBean = inBean;//save the reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.makeRed();
  }//end actionPerformed()
}//end class RedActionListener
//-------------------------------------------------------//

class BlueActionListener implements ActionListener{
  Beans05 myBean;//save a reference to the bean here
  
  BlueActionListener(Beans05 inBean){//constructor
    myBean = inBean;//save the reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.makeBlue();
  }//end actionPerformed()
}//end class BlueActionListener
//=======================================================//

//The following class is used to instantiate objects that
// will be bound to the bean in such a way as to be 
// notified of changes in the property values in the bean 
// object.  When notified of such changes, code in the
// propertyChange() method of this class extracts and
// displays information about the bean and the properties.
class MyPropertyChangeListener 
                         implements PropertyChangeListener{
  String theID; //store listener object ID here
  
  void setTheID(String nameIn){
    //method to save the ID of the object
    theID = nameIn;
  }//end setTheID()
    
  public void propertyChange(PropertyChangeEvent event){
    //Extract and display information about the event
    System.out.println(theID + " notified of change");
    System.out.println("Property change source: " 
                                      + event.getSource());
    System.out.println("Property name: " 
                                + event.getPropertyName());
    System.out.println("New property value: " 
                                    + event.getNewValue());
    System.out.println("Old property value: " 
                                    + event.getOldValue());
    System.out.println();//blank line
  }//end propertyChange()
}//end MyPropertyChangeListener class
//=======================================================//

class Terminate extends WindowAdapter{
  public void windowClosing(WindowEvent e){
    //terminate the program when the window is closed  
    System.exit(0);
  }//end windowClosing
}//end class Terminate
//=======================================================//