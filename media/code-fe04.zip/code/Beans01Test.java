/*File Beans01Test.java.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed 
under JDK 1.1.1.

The purpose is to test the bean named Beans01.java in a 
Frame.

A Bean01 object is placed in the frame along with eight 
buttons. The visual manifestation of the Bean object is a 
colored square.

One pair of buttons exercises the "get" and "set" color 
properties of the Bean.

A second pair of buttons invokes the makeRed() and 
makeBlue() methods of the Bean.

A third pair of buttons invokes the addActionListener() 
and removeActionListener() methods of the Bean.

A fourth pair of buttons exercises the "set" and "is" 
boolean properties of the Bean.

For those cases where information is returned from the 
Bean, it is displayed on the standard output device.

The program was tested using JDK 1.1.1 and Win95.  
**********************************************************/

import java.awt.*;
import java.awt.event.*;
//=======================================================//
public class Beans01Test extends Frame{
  public static void main(String[] args){
    new Beans01Test();
  }//end main

  public Beans01Test(){//constructor
    setTitle("Copyright 1997, R.G.Baldwin");
    setLayout(new FlowLayout());
    Beans01 myBean = new Beans01();//instantiate Bean obj
    add(myBean);//Add it to the Frame
    
    //Instantiate several test buttons 
    Button buttonToSetColor = new Button(
                                     "set color property");
    Button buttonToGetColor = new Button(
                                     "get color property");
    Button buttonToInvokeRedMethod = new Button(
                                  "Invoke makeRed Method");
    Button buttonToInvokeBlueMethod = new Button(
                                 "Invoke makeBlue Method");
    Button buttonToAddActionListener = new Button(
                                    "Add Action Listener");
    Button buttonToRemoveActionListener = new Button(
                                 "Remove Action Listener");
    Button buttonToSetBooleanProperty = new Button(
                                   "Set boolean Property");
    Button buttonToGetBooleanProperty = new Button(
                                   "Get boolean Property");
  
    //Add the test buttons to the frame  
    add(buttonToSetColor);
    add(buttonToGetColor);
    add(buttonToInvokeRedMethod);
    add(buttonToInvokeBlueMethod);
    add(buttonToAddActionListener);
    add(buttonToRemoveActionListener);
    add(buttonToSetBooleanProperty);
    add(buttonToGetBooleanProperty);
    
    setSize(250,350);
    setVisible(true);

    //Register action listener objects for all the test 
    // buttons    
    buttonToSetColor.addActionListener(
                             new SetColorListener(myBean));
    buttonToGetColor.addActionListener(
                             new GetColorListener(myBean));
    buttonToInvokeRedMethod.addActionListener(
                            new RedActionListener(myBean));
    buttonToInvokeBlueMethod.addActionListener(
                           new BlueActionListener(myBean));
    buttonToAddActionListener.addActionListener(
                          new AdditActionListener(myBean));
    buttonToRemoveActionListener.addActionListener(
                            new RmovitActionLstnr(myBean));
    buttonToSetBooleanProperty.addActionListener(
                             new SetBoolPropLstnr(myBean));
    buttonToGetBooleanProperty.addActionListener(
                             new GetBoolPropLstnr(myBean));
    
    //terminate when frame is closed
    this.addWindowListener(new Terminate());
  }//end constructor
}//end class Beans01Test.java
//=======================================================//
//The following two classes are used to instantiate 
// objects to be registered to listen to two of the 
// buttons on the test panel.  When the 
// buttonToSetBooleanProperty is pressed, the boolean 
// property is set to false. When the 
// buttonToGetBooleanProperty is pressed, the current 
// boolean property is displayed on the standard output 
// device.

class SetBoolPropLstnr implements ActionListener{
  Beans01 myBean;
  
  SetBoolPropLstnr(Beans01 inBean){//constructor
    myBean = inBean;
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.setMyBooleanProperty(false);
  }//end actionPerformed()
}//end class SetBoolPropLstnr
//=======================================================//
class GetBoolPropLstnr implements ActionListener{
  Beans01 myBean;
  
  GetBoolPropLstnr(Beans01 inBean){//constructor
    myBean = inBean;
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    System.out.println(myBean.isMyBooleanProperty());
  }//end actionPerformed()
}//end class GetBoolPropLstnr

//=======================================================//

//The following two classes are used to instantiate 
// objects to be registered to listen to two of the 
// buttons on the test panel.  When the setColor button is
// pressed, the Color property is set to green. When the 
// getColor button is pressed, the current color is 
// displayed on the standard output device.
class SetColorListener implements ActionListener{
  Beans01 myBean;
  
  SetColorListener(Beans01 inBean){//constructor
    myBean = inBean;
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.setColor(Color.green);
  }//end actionPerformed()
}//end class SetColorListener
//=======================================================//
class GetColorListener implements ActionListener{
  Beans01 myBean;
  
  GetColorListener(Beans01 inBean){//constructor
    myBean = inBean;
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    System.out.println(myBean.getColor().toString());
  }//end actionPerformed()
}//end class GetColorListener

//=======================================================//
//The following class is used to instantiate a dummy 
// ActionListener object which is passed to the 
// addActionListener() and removeActionListener() methods
// of the Bean.
class MyDummyActionListener implements ActionListener{
  public void actionPerformed(ActionEvent e){
  }//end empty actionPerformed() method
}//end class MyDummyActionListener
//=======================================================//
//The following two classes are used to instantiate 
// objects to be registered to listen to two of the 
// buttons on the test panel.  When the buttons are 
// pressed, the addActionListener() and 
// removeActionListener() methods of the Bean are invoked.
class AdditActionListener implements ActionListener{
  Beans01 myBean;
  
  AdditActionListener(Beans01 inBean){//constructor
    myBean = inBean;
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.addActionListener(new MyDummyActionListener());
  }//end actionPerformed()
}//end class AdditActionListener
//=======================================================//
class RmovitActionLstnr implements ActionListener{
  Beans01 myBean;
  
  RmovitActionLstnr(Beans01 inBean){//constructor
    myBean = inBean;
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.removeActionListener(new MyDummyActionListener());
  }//end actionPerformed()
}//end class AdditActionListener
//=======================================================//
//The following two classes are used to instantiate 
// objects to be registered to listen to two of the 
// buttons on the test panel.  When the buttons are 
// pressed, these objects invoke methods of the Bean under
// test. The first class invokes the makeRed() method and
// the second class invokes the makeBlue() method.
class RedActionListener implements ActionListener{
  Beans01 myBean;
  
  RedActionListener(Beans01 inBean){//constructor
    myBean = inBean;
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.makeRed();
  }//end actionPerformed()
}//end class RedActionListener
//=======================================================//
class BlueActionListener implements ActionListener{
  Beans01 myBean;
  
  BlueActionListener(Beans01 inBean){//constructor
    myBean = inBean;
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.makeBlue();
  }//end actionPerformed()
}//end class RedActionListener
//=======================================================//
class Terminate extends WindowAdapter{
  public void windowClosing(WindowEvent e){
    System.exit(0);//terminate the program
  }//end windowClosing
}//end class Terminate
//=======================================================//
