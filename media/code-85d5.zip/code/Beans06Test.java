/*File Beans06Test.java Copyright 1997, R.G.Baldwin

This program was designed to be compiled and executed 
under JDK 1.1.3 or later.

This program is designed to test the constrained property
aspects of the bean class named Beans06.

The program has been simplified as much as possible in an
attempt to make it understandable.

You will need to refer to the comments in the source code
for the Beans06 bean class to fully understand how this 
test program works.

The visual manifestation of the Beans06 bean is a colored
square.  The bean is placed in a Frame object by this
test program.  The square is initially yellow.  

The bean has one property named theColor which controls 
the color of the square.

Two exposed methods of the bean, makeRed() and makeBlue(), 
can be invoked to change the color to red or blue.

Invoking the makeRed() or makeBlue() methods changes the 
value of the property named theColor which in turn changes
the color of the square.  

You can also change the value of the property named
theColor by invoking the setTheColor() method.  In this
case you can pass in any color as a parameter.

The property named theColor is a bound constrained 
property.  The bean supports a multicast list of
PropertyChangeListener objects and also supports a 
multicast list of VetoableChangeListener objects.

PropertyChangeListener objects are simply notified 
whenever a change in a property value occurs.

VetoableChangeListener objects are notified of a proposed 
change in the property value and have the opportunity to 
veto the change by raising a PropertyVetoException.

The program begins with the yellow square bean and three
buttons in a frame on the screen. The buttons are labeled
Red, Green, and Blue.

The Red and Blue buttons invoke the makeRed() and 
makeBlue() methods discussed above.

The Green button invokes the setTheColor() method causing
the color green to be passed in as a parameter.  
Therefore, clicking this button will attempt to change the
value of the property named theColor to green.

A listener class is defined which implements both the
PropertyChangeListener interface and the 
VetoableChangeListener interface.  As a result, a listener
object of this class can register to be notified of
proposed property changes with veto authority and can also
register to be notified of actual changes.

One such listener object is instantiated and registered
to listen for both propertyChange() and vetoableChange()
events.

This object is designed to veto any proposal to change the
value of the property to green.

Therefore, if you click the Red button, the square will 
turn to red and the following will appear on the screen:

Veto Listener, 
New property value: java.awt.Color[r=255,g=0,b=0]
Change Listener, 
New property value: java.awt.Color[r=255,g=0,b=0]

If you click the Blue button, the square will change to 
blue and the following will appear on the screen.

Veto Listener, 
New property value: java.awt.Color[r=0,g=0,b=255]
Change Listener, 
New property value: java.awt.Color[r=0,g=0,b=255]

If you click the Green button, the color of the square 
will not change.  The following will appear on the 
screen indicating that the proposed new color was vetoed
and another event was multicast which rolled the property 
value back to its value before the proposed change.

Veto Listener, 
New property value: java.awt.Color[r=0,g=255,b=0]
Veto Listener, 
New property value: java.awt.Color[r=0,g=0,b=255]
java.beans.PropertyVetoException: No green allowed

If you then click on the Red button, the color of the 
square will change to red and the following will appear
on the screen:
  
Veto Listener, 
New property value: java.awt.Color[r=255,g=0,b=0]
Change Listener, 
New property value: java.awt.Color[r=255,g=0,b=0]  

In all of the above examples, line breaks were manually
inserted in the text to make it fit better in this format.

Although this sample program was constructed for 
simplicity having only one property in the bean and one
listener object, the structure of the Beans06 bean class
will support any number of listener objects in either 
category.  

Obviously the number of properties could also be expanded
to a very large number.  This would require more 
processing on the part of the objects.  With the
structure being used, every object registered to be 
notified of proposed changes would be notified of every
proposed change on every property.  Likewise, every object
registered to be notified of actual changes would be 
notified of every actual change on every property.

Each notification event contains the name of the property
to which the actual or proposed change applies.  The
objects would have to use that information to make 
decisions on the basis of property names and proposed
changes in property values.

=========================================================*/

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;
//=======================================================//

public class Beans06Test extends Frame{
  public static void main(String[] args){
    new Beans06Test();
  }//end main
  //-----------------------------------------------------//

  public Beans06Test(){//constructor
    setTitle("Copyright 1997, R.G.Baldwin");
    setLayout(new FlowLayout());
    //instantiate a Bean object
    Beans06 myBean = new Beans06();
    add(myBean);//Add it to the Frame
    
    //Instantiate several test buttons 
    Button buttonToSetTheColor = new Button("Green");
    Button buttonToInvokeRedMethod = new Button("Red");
    Button buttonToInvokeBlueMethod = new Button("Blue");
                      
    //Add the test buttons to the frame  
    add(buttonToInvokeRedMethod);    
    add(buttonToSetTheColor);
    add(buttonToInvokeBlueMethod);
    
    //Size the frame and make it visible
    setSize(250,350);
    setVisible(true);

    //Register action listener objects for all the test 
    // buttons    
    buttonToSetTheColor.addActionListener(
                          new SetTheColorListener(myBean));
    buttonToInvokeRedMethod.addActionListener(
                            new RedActionListener(myBean));
    buttonToInvokeBlueMethod.addActionListener(
                           new BlueActionListener(myBean));

                           
    //Instantiate and register an object to listen for 
    // proposed and actual changes in the bean's property.
    // This listener object has the ability to veto
    // proposed changes.
    MyPropertyListenerClass myListenerObject = 
                            new MyPropertyListenerClass();
    myBean.addPropertyChangeListener(myListenerObject);
    myBean.addVetoableChangeListener(myListenerObject);    
                           
    //Terminate program when Frame is closed    
    this.addWindowListener(new Terminate());
  }//end constructor
}//end class Beans06Test
//=======================================================//

//An object of this class is instantiated and registered
// to listen for actionPerformed() events on the button
// labeled "setTheColor".

// When the setTheColor button is pressed, the object
// invokes the setTheColor() method on the bean passing in
// a color parameter of green.

class SetTheColorListener implements ActionListener{
  Beans06 myBean;//save a reference to the bean here
  
  SetTheColorListener(Beans06 inBean){//constructor
    myBean = inBean;//save a reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.setTheColor(Color.green);
  }//end actionPerformed()
}//end class SetTheColorListener
//-------------------------------------------------------//

//The following two classes are used to instantiate objects
// which are registered to listen to two of the buttons on
// the test panel.  When the corresponding  buttons are 
// pressed, these objects invoke methods of the bean under 
// test. The first class invokes the makeRed() method and
// the second class invokes the makeBlue() method.

class RedActionListener implements ActionListener{
  Beans06 myBean;//save a reference to the bean here
  
  RedActionListener(Beans06 inBean){//constructor
    myBean = inBean;//save the reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.makeRed();
  }//end actionPerformed()
}//end class RedActionListener
//-------------------------------------------------------//

class BlueActionListener implements ActionListener{
  Beans06 myBean;//save a reference to the bean here
  
  BlueActionListener(Beans06 inBean){//constructor
    myBean = inBean;//save the reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.makeBlue();
  }//end actionPerformed()
}//end class BlueActionListener
//=======================================================//

//The following class is used to instantiate objects that
// will be bound to the bean in such a way as to be 
// notified of proposed changes and actual changes in the 
// property values in the bean object.

//When notified of a proposed or actual change, the object
// displays the actual or proposed new property value.

//When notified of a proposed change, the object has the
// ability to veto the change by raising a 
// PropertyVetoException.  The design of this class is
// such that any proposed change to the color green will
// vetoed.

class MyPropertyListenerClass 
  implements PropertyChangeListener,VetoableChangeListener{
    
  public void propertyChange(PropertyChangeEvent event){
    //Extract and display the new value
    System.out.println("Change Listener, New property value: " 
                                    + event.getNewValue());
  }//end propertyChange()
    
  public void vetoableChange(PropertyChangeEvent event)
                              throws PropertyVetoException{
    //Extract and display proposed new value                                
    System.out.println("Veto Listener, New property value: " 
                                    + event.getNewValue());
    //Throw an exception on proposed value of green. This
    // will veto the change.
    if(event.getNewValue().equals(Color.green))                                                     
      throw new PropertyVetoException(
                                 "No green allowed",event);
  }//end vetoableChange()    
}//end MyPropertyListenerClass class
//=======================================================//

class Terminate extends WindowAdapter{
  public void windowClosing(WindowEvent e){
    //terminate the program when the window is closed  
    System.exit(0);
  }//end windowClosing
}//end class Terminate
//=======================================================//