/*File Beans07.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed 
under JDK 1.1.3 or later.

This program illustrates the use of beans with multiple
properties which are both bound and constrained.

This bean appears on the screen as a colored rectangle
containing a date and time.  The color as well as the date
and time are based on the current values of corresponding 
properties.

The bean has a Color property named theColor and a Date 
property named theDate. Both of these properties are bound
and constrained.

The bean has a property named preferredSize that is neither
bound nor constrained 

This bean supports propertyChange and vetoableChange 
notification lists for the property values.  Other objects 
can register to be notified of a proposed change in 
property values and can veto the change.  A proposed change
that is vetoed does not take place.  Other objects can also
register to be notified of actual changes in property 
values.
 

A description of the bean as determined by the program 
named Introspect01 follows:
-------  
Name of bean:  Beans07
Class of bean: class Beans07

==== Properties: ====
Name: preferredSize
 Type:       class java.awt.Dimension
 Get method: public synchronized java.awt.Dimension 
                                 Beans07.getPreferredSize()
 Set method: null
Name: theDate
 Type:       class java.util.Date
 Get method: null
 Set method: public synchronized void 
                         Beans07.setTheDate(java.util.Date)
Name: theColor
 Type:       class java.awt.Color
 Get method: null
 Set method: public synchronized void 
                        Beans07.setTheColor(java.awt.Color)

==== Events: ====
Event Name: vetoableChange
 Add Method:    public synchronized void 
                   Beans07.addVetoableChangeListener(
                         java.beans.VetoableChangeListener)
 Remove Method: public synchronized void 
                   Beans07.removeVetoableChangeListener(
                         java.beans.VetoableChangeListener)
 Event Type: vetoableChange
 
Event Name: propertyChange
 Add Method:    public synchronized void 
                   Beans07.addPropertyChangeListener(
                         java.beans.PropertyChangeListener)
 Remove Method: public synchronized void 
                   Beans07.removePropertyChangeListener(
                         java.beans.PropertyChangeListener)
 Event Type: propertyChange

==== Methods: ====
setTheDate
removePropertyChangeListener
setTheColor
removeVetoableChangeListener
getPreferredSize
addPropertyChangeListener
addVetoableChangeListener
-------

  The following methods:
    setTheColor()
    setTheDate()
      
  both provide the opportunity for a VetoableChangeListener
  object to veto a proposed new value for the property.
    
  Each of these methods receives a proposed property value
  as a parameter when it is invoked. The method saves the 
  current value of the property in an instance variable 
  named old_____.  Then it makes a call to the method named
  notifyVetoableChange() inside a try block.
  
  notifyVetoableChange() broadcasts a vetoableChange()
  event to all of the VetoableChangeListener objects that
  are registered to receive such an event.  Any listener
  object that wants to veto the change throws a
  PropertyVetoException which finds its way back to the 
  method listed above that invoked notifyVetoableChange() 
  in the first place.
  
  When the exception is thrown, it is caught in a catch
  block.  The code in the catch block restores the
  property value to its original value. In other words, the
  proposed new value is discarded and replaced by the value
  of the property before the proposed new value was 
  received.
  
  This proposed new value then becomes the current value
  and is used to set the background color of the bean
  or to set the new date and time.
  
  The proposed new value is also compared with the value
  of the property before the proposed new value was
  received.  If they are different, meaning that a 
  property change has occurred, the notifyPropertyChange()
  method is invoked to broadcase a propertyChange() event
  to all PropertyChangeListener objects registered to 
  receive such an event.

  An important aspect of the behavior of this bean is 
  based on the use of the fireVetoableChange() method of
  the VetoableChangeSupport class to actually broadcast 
  the event. A description of this method follows.
  
  Note in particular the behavior of this method when
  someone vetos the change.
  
  ------
  public void fireVetoableChange(String propertyName,
              Object oldValue,
              Object newValue) throws PropertyVetoException


    Report a vetoable property update to any registered 
    listeners. If anyone vetos the change, then fire a new 
    event reverting everyone to the old value and then 
    rethrow the PropertyVetoException. 

    No event is fired if old and new are equal and non-null 

    Parameters: 
        propertyName - The name of the property that was 
                       changed. 
        oldValue - The old value of the property. 
        newValue - The new value of the property. 
    Throws: PropertyVetoException 
        if the recipient wishes the property change to be 
        rolled back. 


Additional comments describing the bean are scattered
throughout the code.

This bean was tested using the test program named 
Beans07Test using JDK 1.1.3 under Win95.
//=======================================================//
*/

import java.awt.event.*;
import java.awt.*;
import java.io.Serializable;
import java.util.*;
import java.beans.*;
//=======================================================//
//All beans should implement the Serializable interface
public class Beans07 extends Label 
                                   implements Serializable{

  //The following instance variables are used to store the
  // current property value and proposed new property
  // value for both the Color and Date properties.
  protected Color oldColor;
  protected Color newColor;
  protected Date oldDate;
  protected Date newDate;
  
  //The following reference variables are used to access
  // the list maintenance and event firing capabilities
  // of the PropertyChangeSupport and VetoableChangeSupport
  // classs. An object of each of these classes is 
  // instantiated in the constructor.  
  PropertyChangeSupport changeSupportObj;
  VetoableChangeSupport vetoSupportObj;
  //-----------------------------------------------------//
  
  public Beans07(){//constructor
    //Initialize the property values and the display
    newColor = Color.yellow;
    setBackground(newColor);
    
    newDate = new Date();
    setText(newDate.toString());
    
    //Instantiate objects of the support classes to handle
    // list maintenance and event firing tasks.  The
    // constructor for the support classes requires this 
    // object as a paremeter.  The parameter is used as the
    // source of the events when they are fired.
    changeSupportObj = new PropertyChangeSupport(this);
    vetoSupportObj = new VetoableChangeSupport(this);     
  }//end constructor
  //-----------------------------------------------------//

  //This method defines the preferred display size of the 
  // bean object.  
  public synchronized Dimension getPreferredSize(){
    return new Dimension(200,50);
  }//end getPreferredSize()
  //-----------------------------------------------------//
  
  //The following "set" method in conjunction with the 
  // instance variables named oldColor and newColor 
  // constitute a write-only property named theColor.  
  public synchronized void setTheColor(Color inColor){
    oldColor = newColor;//save current color
    newColor = inColor;//proposed new color
    
    try{//test to see if anyone vetos the new color
      notifyVetoableChange("theColor");
    }catch(PropertyVetoException exception){
      //Someone vetoed the new color.  Don't use newColor.
      newColor = oldColor;// Restore oldColor instead
    }//end catch

    if(!newColor.equals(oldColor)){//if color changed
      this.setBackground(newColor);//display new color
      //notify property listeners of property change      
      notifyPropertyChange("theColor");
    }//end if 
    
  }//end setTheColor()

  //-----------------------------------------------------//
  //The following "set" method in conjunction with the 
  // instance variables named oldDate and newDate 
  // constitute a write-only property named theDate.  
  public synchronized void setTheDate(Date inDate){
    oldDate = newDate;//save current date
    newDate = inDate;//proposed new date
    
    try{//test to see if anyone vetos the new date
      notifyVetoableChange("theDate");
    }catch(PropertyVetoException exception){
      //Someone vetoed the new date.  Don't use newDate.
      newDate = oldDate;// Restore oldDate instead
      //Display the veto exception
      System.out.println(exception.getMessage());
    }//end catch

    if(!newDate.equals(oldDate)){//if date changed
      this.setText(newDate.toString());//display new date
      //notify property listeners of property change      
      notifyPropertyChange("theDate");
    }//end if    
  }//end setTheColor()  
  //-----------------------------------------------------//

  //The following two methods are used to maintain a list
  // of listener objects who request to be registered as
  // PropertyChangeListener objects, or who request to be 
  // removed from the list.  
  
  //Add a property change listener object to the list.
  public synchronized void addPropertyChangeListener(
                          PropertyChangeListener listener){
    //Pass the task to the support class.
    changeSupportObj.addPropertyChangeListener(listener);
  }//end addPropertyChangeListener
  //-----------------------------------------------------//

  //Remove a property change listener from the list.
  public synchronized void removePropertyChangeListener(
                          PropertyChangeListener listener){
    //Pass the task to the support class.
    changeSupportObj.removePropertyChangeListener(listener);
  }//end removePropertyChangeListener()
  //-----------------------------------------------------//
  
  //The following two methods are used to maintain a list
  // of listener objects who request to be registered
  // as VetoableChangeListener objects, or who request to 
  // be removed from the list.  
  
  //Add a vetoable change listener object to the list.
  public synchronized void addVetoableChangeListener(
                          VetoableChangeListener listener){
    //Pass the task to the support class.
    vetoSupportObj.addVetoableChangeListener(listener);
  }//end addVetoableChangeListener
  //-----------------------------------------------------//

  //Remove a vetoable change listener from the list.
  public synchronized void removeVetoableChangeListener(
                          VetoableChangeListener listener){
    //Pass the task to the support class.
    vetoSupportObj.removeVetoableChangeListener(listener);
  }//end removeVetoableChangeListener()  
  //-----------------------------------------------------//
  
  //The following method is used to notify 
  // PropertyChangeListener objects of changes in the 
  // properties.  The incoming parameter is the name of the
  // property that has changed.  
  protected void notifyPropertyChange(
                                   String changedProperty){
    if(changedProperty.compareTo("theColor") == 0)
      //TheColor property has changed, pass color info
      changeSupportObj.firePropertyChange(
                        changedProperty,oldColor,newColor);
      else //TheDate property has changed, pass date info
      changeSupportObj.firePropertyChange(
                        changedProperty,oldDate,newDate);
                              
  }//end notifyPropertyChange()
  //-----------------------------------------------------//

  //The following method is used to notify 
  // VetoableChangeListener objects of proposed changes in 
  // the property values.  The incoming parameter is the 
  // name of the property that is proposed to be changed.
  
  // This method uses the fireVetoableChange() method of 
  // the VetoableChangeSupport class to actually fire the 
  // event.  As discussed earlier in this file, the
  // fireVetoableChange method actually performs some data
  // processing and does more than simply fire the event.
  // In the event of a veto, it fires a second event with
  // the value of the property that existed prior to the
  // proposed change.
  protected void notifyVetoableChange(
                          String vetoableProperty)
                              throws PropertyVetoException{
    if(vetoableProperty.compareTo("theColor") == 0)
      //theColor property is proposed to be changed
      vetoSupportObj.fireVetoableChange(
                       vetoableProperty,oldColor,newColor);
    else //theDate property is proposed to be changed
      vetoSupportObj.fireVetoableChange(
                       vetoableProperty,oldDate,newDate);
  }//end notifyVetoableChange()  
  
}//end class Beans07.java
//=======================================================//