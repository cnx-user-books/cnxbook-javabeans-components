/*File Beans07Test.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed 
under JDK 1.1.3 or later.

This program is designed to test the constrained property
aspects of the bean class named Beans07 for multiple
properties and multiple listener objects.

You will need to refer to the comments in the source code
for the Beans07 bean class to fully understand how this 
test program works.

The visual manifestation of the Beans07 bean is a colored
rectangle with a date and time displayed in the rectangle.

The bean is placed in a Frame object by this test program.

The rectangle is initially yellow.  

The bean has two bound and constrained properties named
theColor and theDate which control the color of the 
rectangle and the date and time displayed in the rectangle.

You can change the color of the rectangle by invoking the
setTheColor() method on the bean and passing in a Color as 
a parameter.

You can change the date and time displayed in the 
rectangle by invoking the setTheDate() method on the bean
and passing a Date object as a parameter.

The bean supports a multicast list of 
PropertyChangeListener objects and also supports a 
multicast list of VetoableChangeListener objects for both
of the bound and constrained properties.

PropertyChangeListener objects are simply notified 
whenever a change in a property value occurs.

VetoableChangeListener objects are notified of a proposed 
change in the property value and have the opportunity to 
veto the change by raising a PropertyVetoException.

This program begins with a yellow rectangular bean
containing a date and time along with five buttons in a 
frame on the screen. The buttons are labeled Red, Green, 
Blue, Orange, and Date.

Clicking one of the buttons with a color label causes the
setTheColor() method to be invoked on the bean with the
indicated color being passed in as a parameter.

Clicking the date button causes the setTheDate() method to
be invoked on the bean, passing in a Date object containing
the current date and time.

A listener class is defined which implements both the
PropertyChangeListener interface and the 
VetoableChangeListener interface.  As a result, a listener
object of this class can register to be notified of
proposed property changes with veto authority and can also
register to be notified of actual changes.

The constructor for this listener class also allows a 
String object and a Color value to be passed in as a 
parameter.

The String object is used as an identifier when information
about the listener object is displayed.

The Color value is used to establish a color that will be 
vetoed by the listener object.

Two such listener objects are instantiated and registered
to listen for both propertyChange() and vetoableChange()
events.

One object is named Joe and will veto attempts to change
the Color property to green.

The other object is named Tom and will veto attempts to
change the Color property to orange.


If you click the Red button, the rectangle will change to 
red and the following will appear on the screen:

Joe Change Listener
  New property value: java.awt.Color[r=255,g=0,b=0]
Tom Change Listener
  New property value: java.awt.Color[r=255,g=0,b=0]


If you click the Green button, the color of the rectangle 
will not change.  The following will appear on the screen 
indicating that the proposed new color was vetoed.

Joe vetos java.awt.Color[r=0,g=255,b=0]


If you click the Blue button, the rectangle will change to 
blue and the following will appear on the screen.

Joe Change Listener
  New property value: java.awt.Color[r=0,g=0,b=255]
Tom Change Listener
  New property value: java.awt.Color[r=0,g=0,b=255]


If you click the Orange button, the color of the rectangle 
will not change.  The following will appear on the screen 
indicating that the proposed new color was vetoed.

Tom vetos java.awt.Color[r=255,g=200,b=0]


If you then click on the Red button, the color of the 
rectangle will change to red and the following will appear
on the screen:

Joe Change Listener
  New property value: java.awt.Color[r=255,g=0,b=0]
Tom Change Listener
  New property value: java.awt.Color[r=255,g=0,b=0]  

  
If you click on the Date button, the new date and time will
appear in the colored rectangle and the following will
appear on the screen:

Joe Change Listener
  New property value: Sun Oct 19 15:14:07 CDT 1997
Tom Change Listener
  New property value: Sun Oct 19 15:14:07 CDT 1997



=========================================================*/

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;
//=======================================================//
public class Beans07Test extends Frame{
  public static void main(String[] args){
    new Beans07Test();
  }//end main
  //-----------------------------------------------------//

  public Beans07Test(){//constructor
    setTitle("Copyright 1997, R.G.Baldwin");
    setLayout(new FlowLayout());
    //instantiate a Bean object
    Beans07 myBean = new Beans07();
    add(myBean);//Add it to the Frame
    
    //Instantiate several test buttons 
    Button buttonToSetToGreen = new Button("Green");
    Button buttonToSetToRed = new Button("Red");
    Button buttonToSetToBlue = new Button("Blue");
    Button buttonToSetToOrange = new Button("Orange");    
    Button buttonToSetTheDate = new Button("Date");
                      
    //Add the test buttons to the frame  
    add(buttonToSetToRed);    
    add(buttonToSetToGreen);
    add(buttonToSetToBlue);
    add(buttonToSetToOrange);
    add(buttonToSetTheDate);
    
    //Size the frame and make it visible
    setSize(250,350);
    setVisible(true);

    //Register action listener objects for all the test 
    // buttons    
    buttonToSetToGreen.addActionListener(
              new SetTheColorListener(myBean,Color.green));
    buttonToSetToRed.addActionListener(
              new SetTheColorListener(myBean,Color.red));
    buttonToSetToBlue.addActionListener(
              new SetTheColorListener(myBean,Color.blue));
    buttonToSetToOrange.addActionListener(
             new SetTheColorListener(myBean,Color.orange));                  
    buttonToSetTheDate.addActionListener(
              new SetTheDateListener(myBean));    

    //Instantiate and register  objects to listen for 
    // proposed and actual changes in the bean's property
    // values. These listener objects havethe ability to 
    // veto proposed changes.
    //This object is named Joe and vetos the green color
    MyPropertyListenerClass joeListenerObject = 
            new MyPropertyListenerClass("Joe",Color.green);
    myBean.addPropertyChangeListener(joeListenerObject);
    myBean.addVetoableChangeListener(joeListenerObject);
    
    //This object is named Tom and vetos the orange color
    MyPropertyListenerClass tomListenerObject = 
          new MyPropertyListenerClass("Tom",Color.orange);
    myBean.addPropertyChangeListener(tomListenerObject);
    myBean.addVetoableChangeListener(tomListenerObject);
                               
    //Terminate program when Frame is closed    
    this.addWindowListener(new Terminate());
  }//end constructor
}//end class Beans07Test
//=======================================================//
//An object of this class will invoke the setTheColor()
// method on the bean passing a specified color as a 
// parameter.  The specified color is passed as a parameter
// to the constructor of this class.  
class SetTheColorListener implements ActionListener{
  Beans07 myBean;//save a reference to the bean here
  Color colorToSet;//save the new color here
  
  //constructor
  SetTheColorListener(Beans07 inBean,Color inColor){
    myBean = inBean;//save a reference to the bean
    colorToSet = inColor;//save the new color
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.setTheColor(colorToSet);
  }//end actionPerformed()
}//end class SetTheColorListener
//=======================================================//

//An object of this class will invoke the setTheDate()
// method on the bean passing a Date object as a parameter.
// The date object is constructed to contain the current 
// date and time.
class SetTheDateListener implements ActionListener{
  Beans07 myBean;//save a reference to the bean here
  
  //constructor
  SetTheDateListener(Beans07 inBean){
    myBean = inBean;//save a reference to the bean
  }//end constructor
  
  public void actionPerformed(ActionEvent e){
    myBean.setTheDate(new Date());
  }//end actionPerformed()
}//end class SetTheDateListener
//=======================================================//

//The following class is used to instantiate objects that
// will be bound to the bean in such a way as to be 
// notified of proposed changes and actual changes in the 
// property values in the bean object.

//When notified of a proposed or actual change, the object
// displays the actual or proposed new property value.

//When notified of a proposed change, the object has the
// ability to veto the change by raising a 
// PropertyVetoException.  

//The constructor for this class accepts a String object
// and a Color parameter as incoming parameters.  The
// String is used to identify the object when information
// is displayed.  The Color parameter specifies a color
// that will be vetoed by the object if an attempt is
// made to change the Color property of the bean to that
// Color value.

//Note that this class implements PropertyChangeListener
// and VetoableChangeListener

class MyPropertyListenerClass 
  implements PropertyChangeListener,VetoableChangeListener{
  String objID; //store the object ID here
  Color vetoColor; //store the color to be vetoed here
  
  //constructor
  MyPropertyListenerClass(String idIn,Color vetoColorIn){
    objID = idIn;//save the object ID
    vetoColor = vetoColorIn;//save the veto color
  }//end constructor
    
  public void propertyChange(PropertyChangeEvent event){
    //Extract and display the new value
    System.out.println(
         objID + " Change Listener\n  New property value: "
                                    + event.getNewValue());
  }//end propertyChange()
    
  public void vetoableChange(PropertyChangeEvent event)
                              throws PropertyVetoException{
    if(event.getNewValue() == vetoColor){//test for veto 
      System.out.println(
                  objID + " vetos " + event.getNewValue());
      //Throw an exception on proposed change. This will 
      // veto the change.
      throw new PropertyVetoException("VETO",event);
    }//end if
  }//end vetoableChange()    
}//end MyPropertyListenerClass class
//=======================================================//

class Terminate extends WindowAdapter{
  public void windowClosing(WindowEvent e){
    //terminate the program when the window is closed  
    System.exit(0);
  }//end windowClosing
}//end class Terminate
//=======================================================//