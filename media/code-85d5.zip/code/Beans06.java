/*File Beans06.java Copyright 1997, R.G.Baldwin

This program was designed to be compiled and executed 
under JDK 1.1.3 or later.

This program illustrates the use of beans with a property
which is both bound and constrained.

The bean has one property named theColor.  Two separate
instance variables named oldColor and newColor are used
to maintain the value of the property.

Applying introspection to the bean yields the following:
  
Name of bean:  Beans06
Class of bean: class Beans06

==== Properties: ====
Name: preferredSize
 Type:       class java.awt.Dimension
 Get method: public synchronized java.awt.Dimension 
                                  Beans06.getPreferredSize()
 Set method: null
Name: theColor
 Type:       class java.awt.Color
 Get method: public synchronized java.awt.Color 
                                       Beans06.getTheColor()
 Set method: public synchronized void 
                         Beans06.setTheColor(java.awt.Color)

==== Events: ====
Event Name: vetoableChange
 Add Method:    public synchronized void 
                       Beans06.addVetoableChangeListener(
                          java.beans.VetoableChangeListener)
 Remove Method: public synchronized void 
                       Beans06.removeVetoableChangeListener(
                          java.beans.VetoableChangeListener)
 Event Type: vetoableChange
 
Event Name: propertyChange
 Add Method:    public synchronized void 
                       Beans06.addPropertyChangeListener(
                          java.beans.PropertyChangeListener)
 Remove Method: public synchronized void 
                       Beans06.removePropertyChangeListener(
                          java.beans.PropertyChangeListener)
 Event Type: propertyChange

==== Methods: ====
makeRed
removePropertyChangeListener
getTheColor
setTheColor
removeVetoableChangeListener
getPreferredSize
addPropertyChangeListener
makeBlue
addVetoableChangeListener

The most significant new addition to this bean class is
the ability for a listener to veto a proposed change in the
value of a property.  When that happens, the proposed new 
property value is discarded and the actual property value 
is not changed.

  The following methods:
    setTheColor()
    makeRed()
    makeBlue()
      
  all provide the opportunity for a VetoableChangeListener
  object to veto a proposed new color value for the 
  property named theColor.  
  
  Each of these methods receives a proposed new color value
  as a parameter when it is invoked. The method saves the 
  current value of the property in the instance variable 
  named oldColor.  Then it makes a call to the method named
  notifyVetoableChange() inside a try block.
  
  The notifyVetoableChange broadcasts a vetoableChange()
  event to all of the VetoableChangeListener objects that
  are registered to receive such an event.  Any listener
  object that wants to veto the change throws a
  PropertyVetoException which finds its way back to method
  listed above that invoked notifyVetoableChange() in the 
  first place.
  
  When the exception is thrown, it is caught in a catch
  block.  The code in the catch block restores the
  property value to its original value and displays the 
  exception.  In other words, the proposed new value is
  replaced by the value of the property before the 
  proposed new value was received.
  
  This proposed new value then becomes the current value
  and is used to set the background color of the bean.
  The proposed new value is also compared with the value
  of the property before the proposed new value was
  received.  If they are different, meaning that a 
  property change has occurred, the notifyPropertyChange()
  method is invoked to broadcast a propertyChange() event
  to all PropertyChangeListener objects registered to 
  receive such an event.

  An important aspect of the behavior of this bean is 
  based on the use of the fireVetoableChange() method of
  the VetoableChangeSupport class to actually broadcast 
  the event. A description of this method follows.  Pay
  particular attention to the behavior of the method in
  the event that someone wants to veto the change.
  
  ------
  public void fireVetoableChange(String propertyName,
              Object oldValue,
              Object newValue) throws PropertyVetoException


    Report a vetoable property update to any registered 
    listeners. If anyone vetos the change, then fire a new 
    event reverting everyone to the old value and then 
    rethrow the PropertyVetoException. 

    No event is fired if old and new are equal and non-null 

    Parameters: 
        propertyName - The name of the property that was 
                       changed. 
        oldValue - The old value of the property. 
        newValue - The new value of the property. 
    Throws: PropertyVetoException 
        if the recipient wishes the property change to be 
        rolled back. 

//=======================================================//
*/

import java.awt.event.*;
import java.awt.*;
import java.io.Serializable;
import java.util.*;
import java.beans.*;
//=======================================================//
//All beans should implement the Serializable interface
public class Beans06 extends Canvas 
                                   implements Serializable{

  //The following instance variables are used to store the
  // current property value and a proposed new property
  // value.
  protected Color oldColor;
  protected Color newColor;
  
  //The following reference variables are used to access
  // the list maintenance and event firing capabilities
  // of the PropertyChangeSupport and VetoableChangeSupport
  // classes. An object of each of these classes is 
  // instantiated in the constructor.  
  PropertyChangeSupport changeSupportObj;
  VetoableChangeSupport vetoSupportObj;
  //-----------------------------------------------------//
  
  public Beans06(){//constructor
    //This bean is a visible square that is initialized to
    // yellow and can then be changed to red or blue by
    // invoking methods of the class named makeRed() and
    // makeBlue().  
    //The color can be set to any color by invoking the 
    // setTheColor() method and passing a color in as a 
    // parameter.
    
    //Initialize the color of the square.
    newColor = Color.yellow;
    setBackground(newColor);
    
    //Instantiate objects of the support classes to handle
    // list maintenance and event firing tasks.  The
    // constructor for these support classes requires this 
    // object as the source of the events.
    changeSupportObj = new PropertyChangeSupport(this);
    vetoSupportObj = new VetoableChangeSupport(this);     
  }//end constructor
  //-----------------------------------------------------//

  //This method defines the preferred display size of the 
  // bean object.  
  public synchronized Dimension getPreferredSize(){
    return new Dimension(50,50);
  }//end getPreferredSize()
  //-----------------------------------------------------//
   
  //This common method is invoked by all three property-
  // changing methods to process the proposed new color.
  void processTheColors(){
      try{//test to see if anyone vetos the new color
      notifyVetoableChange("theColor");
    }catch(PropertyVetoException exception){
      //Someone vetoed the new color.  Don't use newColor.
      newColor = oldColor;// Restore oldColor instead
      //Display the veto exception
      System.out.println(exception);
    }//end catch

    if(!newColor.equals(oldColor)){//if color changed
      this.setBackground(newColor);//display new color
      //notify property listeners of property change      
      notifyPropertyChange("theColor");
    }//end if
  }//end process the colors    
  //-----------------------------------------------------//
  
  //The following "set" and "get" methods in conjunction 
  // with the instance variable named oldColor constitute a
  // property named theColor.  
  public synchronized void setTheColor(Color inColor){
    oldColor = newColor;//save current color
    newColor = inColor;//proposed new color
    
    processTheColors();//go process the proposed new color
    
  }//end setTheColor()

  public synchronized Color getTheColor(){
    return oldColor;
  }//end getTheColor
  //-----------------------------------------------------//

  //The following two methods are exposed to the builder 
  // tool as accessible methods.  
  public synchronized void makeBlue(){
    oldColor = newColor;//save current color
    newColor = Color.blue;//establish proposed new color
    
    processTheColors();//go process the proposed new color    

  }//end makeBlue()

  public synchronized void makeRed(){
    oldColor = newColor;//save current color
    newColor = Color.red;//establish proposed new color
    
    processTheColors();//go process the proposed new color    
     
  }//end makeRed()
  //-----------------------------------------------------//
    
  //The following two methods are used to maintain a list
  // of PropertyChangeListener objects who request to be
  // added to the list or who request to be removed from 
  // the list.  
  
  //Add a property change listener object to the list.
  public synchronized void addPropertyChangeListener(
                          PropertyChangeListener listener){
    //Pass the task on to the support class method.
    changeSupportObj.addPropertyChangeListener(listener);
  }//end addPropertyChangeListener
  //-----------------------------------------------------//

  //Remove a property change listener from the list.
  public synchronized void removePropertyChangeListener(
                          PropertyChangeListener listener){
    //Pass the task on to the support class method.
    changeSupportObj.removePropertyChangeListener(listener);
  }//end removePropertyChangeListener()
  //-----------------------------------------------------//
  
  //The following two methods are used to maintain a list
  // of listener objects who request to be registered
  // as VetoableChangeListener objects, or who request to 
  // be removed from the list.  
  
  //Add a vetoable change listener object to the list.
  public synchronized void addVetoableChangeListener(
                          VetoableChangeListener listener){
    //Pass the task on to the support class method.
    vetoSupportObj.addVetoableChangeListener(listener);
  }//end addVetoableChangeListener
  //-----------------------------------------------------//

  //Remove a vetoable change listener from the list.
  public synchronized void removeVetoableChangeListener(
                          VetoableChangeListener listener){
    //Pass the task on to the support class method.
    vetoSupportObj.removeVetoableChangeListener(listener);
  }//end removeVetoableChangeListener()  
  //-----------------------------------------------------//
  
  //The following method is used to notify listener 
  // objects of changes in the properties.  The incoming
  // parameter is the name of the property that has 
  // changed.  Note that this method makes use of the 
  // firePropertyChange() method of an object of the
  // PropertyChangeSupport class to actually fire the 
  // event.
  protected void notifyPropertyChange(
                                   String changedProperty){
    //Pass the task on to the support class method.
    changeSupportObj.firePropertyChange(
                        changedProperty,oldColor,newColor);
  }//end notifyPropertyChange()
  //-----------------------------------------------------//   

  //The following method is used to notify 
  // VetoableChangeListener objects of proposed changes in
  // the property values.  The incoming parameter is the 
  // name of the property that is proposed to be changed.
  // This method uses the fireVetoableChange() method of 
  // the VetoableChangeSupport class to actually fire the 
  // event.  As discussed earlier in this file, the
  // fireVetoableChange method actually performs some data
  // processing and does more than simply fire the event.
  protected void notifyVetoableChange(
                          String vetoableProperty)
                              throws PropertyVetoException{
    //Pass the task on to the support class method.
    vetoSupportObj.fireVetoableChange(
                       vetoableProperty,oldColor,newColor);

  }//end notifyVetoableChange()  
  
}//end class Beans06.java
//=======================================================//