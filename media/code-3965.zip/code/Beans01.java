/*File Beans01.java.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed 
under JDK 1.1.1.

A Java Bean is a reusable software component that can be 
manipulated visually in a builder tool.  This requires 
careful adherence to a specified interface.

This program produces a skeleton Bean that exhibits many 
of the required interface characteristics of a Bean.

Information about the interface to the bean can be 
provided to the builder tool either by adherence to design
patterns, or by publishing that information in an object 
of a class that implements the BeanInfo interface.  This 
program relies on design patterns.

Some guidelines are:

All beans should implement the Serializable interface so 
that their state can be saved and later restored.

Methods that are to be exposed to the builder tool and to 
other beans must be made public.

All exposed methods should be synchronized to prevent more 
than one thread from calling a method at any given time.

Properties are exposed through the use of public 
"set"/"get" methods. Properties with no "set" method are 
read-only.  Properties with no "get" method are write-only.

The "get" side of a Boolean property may be exposed either
through the use of a public "is" methods or an ordinary 
"get" method.

Events which the bean can multicast are exposed through 
public "add"/"remove" methods.

The program was tested using JDK 1.1.1 and Win95.  
**********************************************************/

//The following package specification is required in order
// to install the Bean in the BeanBox.  The package 
// specification changes depending on where the Bean is 
// installed in the directory structure.
//package sunw.demo.beans01;

import java.awt.event.*;
import java.awt.*;
import java.io.Serializable;
//=======================================================//
//All beans should implement the Serializable interface
public class Beans01 extends Canvas 
                                   implements Serializable{

  //The following two instance variables are used for 
  // properties
  protected Color myColor;
  protected boolean myBooleanInstanceVariable = true;
  
  public Beans01(){//constructor
    myColor = Color.yellow;
    setBackground(myColor);
    sizeToFit();//see discussion below
  }//end constructor

  //The following method and the above call to the method 
  // in the constructor are required to cause the bean to 
  // be the correct size in the BeanBox.  It is not 
  // required when the Bean is tested in an ordinary Frame
  // object.  The reason for the difference hasn't been 
  // determined.
  private void sizeToFit () {
    this.setSize(getPreferredSize());
    Component p = getParent();
    if (p != null) {
      p.invalidate();
      p.doLayout();
    }//end if
  }//end sizeToFit()  

  //This method defines the display size of the object.  
  public synchronized Dimension getPreferredSize(){
    return new Dimension(50,50);
  }//end getPreferredSize()

  //The following "set" and "is" methods in conjunction 
  // with the instance variable myBooleanInstanceVariable
  // constitute a boolean property. For boolean properties,
  // either a "get" method or an "is" method will support
  // the design pattern requirement.
  public synchronized boolean isMyBooleanProperty(){
    return myBooleanInstanceVariable;
  }//end isDummyInstanceVariable()
  
  public synchronized void setMyBooleanProperty(
                                             boolean data){
    myBooleanInstanceVariable = data;
  }//end setMyBooleanProperty

  //The following "set" and "get" methods in conjunction 
  // with the instance variable myColor constitute a 
  // property of type Color.  
  public synchronized void setColor(Color inColor){
    myColor = inColor;
    this.setBackground(myColor);
  }//end setColor()

  public synchronized Color getColor(){
    return myColor;
  }//end getColor

  //The following two methods are exposed to the builder
  // tool as accessible methods.  
  public synchronized void makeBlue(){
    myColor = Color.blue;
    this.setBackground(myColor);
  };//end makeBlue()

  public synchronized void makeRed(){
    myColor = Color.red;
    this.setBackground(myColor);
  };//end makeRed()

  //The following two methods expose to the builder tool
  // the fact that this Bean is able to multicast Action
  // events (but the methods are incomplete for brevity).
  public synchronized void addActionListener(
                                         ActionListener e){
    //Incomplete.  Need to put some substance here
    System.out.println(
                "addActionListener not fully implemented");
  }//end addActionListener()  
  
  public synchronized void removeActionListener(
                                         ActionListener e){
    //Incomplete.  Need to put some substance here
    System.out.println(
             "removeActionListener not fully implemented");
  }//end removeActionListener
  
}//end class Beans01.java

 