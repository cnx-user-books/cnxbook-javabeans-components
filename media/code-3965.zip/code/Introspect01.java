/*File Introspect01.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed
under JDK 1.1.1.

The purpose of this program is to illustrate the use of the
static getBeanInfo() method of the Introspector class to
encapsulate information about a bean in an object of type
BeanInfo.

Once the information about the bean is encapsulated in the
BeanInfo object, a variety of other methods are used to
extract specific types of information about the bean from
the object.

In order to illustrate the behavior of the different
methods being used, the application was applied to the
skeleton bean named Beans01 (discussed in an earlier
lesson) and the output from the program for each section of
code was included as comments in that section.

The output is stored in a file named junk.txt

The program was tested using JDK 1.1.1 and Win95.
**********************************************************/
import java.io.*;
import java.beans.*;
import java.lang.reflect.*;

public class Introspect01
{
  //name of bean class file to be analyzed
  static String myBeanClassName;
  FileWriter fileWriter;
  PrintWriter printWriter;

  //Start the program and get the name of the class file
  // for the bean in the String myBeanClassName
  public static void main(String args[]) throws Exception {
    myBeanClassName = args[0];
    Introspect01 x = new Introspect01();
  }//end main

  public Introspect01() throws Exception {//constructor
    //Open an output file to store the report in.
    fileWriter = new FileWriter("junk.txt");
    printWriter = new PrintWriter(fileWriter);

    //Create an object of type Class that describes the
    // class of the bean. The static method
    // Introspector.getBeanInfo() requires either one or
    // two objects of type Class as parameters.  The
    // forName() method of the Class class returns such an
    // object, given the name of a class as a parameter.
    Class myBeanClassObject = Class.forName(
                                          myBeanClassName);

    //Given the Class object that describes the bean's
    // class, use the static getBeanInfo() method of the
    // Introspector class to obtain information about the
    // class of the bean.  Save this information in an
    // object of type BeanInfo.  The second parameter
    // passed to getBeanInfo() prevents introspection from
    // going further up the inheritance hierarchy.
    BeanInfo beanInfo = Introspector.getBeanInfo(
      myBeanClassObject,myBeanClassObject.getSuperclass());

    //A BeanDescriptor object provides global information
    // about a bean, including its Java class, its
    // displayName, etc. Use the getBeanDescriptor()
    // method to extract information of that type from
    // the beanInfo object and store it in a new
    // BeanDescriptor object. Store the information in the
    // output file using methods designed to extract the
    // name and class of the bean from the beanDescriptor
    // object.  When this application was applied to the
    // skeleton bean named Beans01, the following output
    // was produced by this section of code.
    /*
    Name of bean:  Beans01
    Class of bean: class Beans01
    */
    BeanDescriptor beanDescriptor =
                              beanInfo.getBeanDescriptor();
    printWriter.println("Name of bean:  " +
                                 beanDescriptor.getName());
    printWriter.println("Class of bean: " +
                            beanDescriptor.getBeanClass());
    printWriter.println("");

    //A PropertyDescriptor object describes one property
    // that a Java Bean exports via a pair of accessor
    // methods. Use the getPropertyDescriptors() method
    // to create an array of PropertyDescriptor objects,
    // one for each exported property.  Then store that
    // information in the output file using methods
    // designed to extract the name of the property, the
    // type of the property, the name of the get method,
    // and the name of the set method. When this
    // application was applied to Beans01, the following
    // output was produced by this section of code.  Manual
    // line breaks were inserted to make it fit in the
    // available space.
    /*
    ==== Properties: ====
    Name: color
     Type:       class java.awt.Color
     Get method: public synchronized java.awt.Color
                                         Beans01.getColor()
     Set method: public synchronized void
                           Beans01.setColor(java.awt.Color)
    Name: preferredSize
     Type:       class java.awt.Dimension
     Get method: public synchronized java.awt.Dimension
                                 Beans01.getPreferredSize()
     Set method: null
    Name: myBooleanProperty
     Type:       boolean
     Get method: public synchronized boolean
                              Beans01.isMyBooleanProperty()
     Set method: public synchronized void
                      Beans01.setMyBooleanProperty(boolean)
    */
    printWriter.println("==== Properties: ====");
    PropertyDescriptor[] propertyDescriptor =
                         beanInfo.getPropertyDescriptors();
    for (int i=0; i<propertyDescriptor.length; i++) {
      printWriter.println("Name: " +
                          propertyDescriptor[i].getName());
      printWriter.println(" Type:       " +
                  propertyDescriptor[i].getPropertyType());
      printWriter.println(" Get method: " +
                    propertyDescriptor[i].getReadMethod());
      printWriter.println(" Set method: " +
                   propertyDescriptor[i].getWriteMethod());
    }//end for-loop
    printWriter.println("");


    //An EventSetDescriptor object describes a group of
    // events that a given Java bean fires. Information can
    // be extracted from each object of the type.
    // When this application was applied to the Beans01
    // bean, the following output was produced by this
    // section of code (note that line breaks were
    // inserted during editing).
    /*
    ==== Events: ====
    Event Name: action
     Add Method:    public synchronized void Beans01.
           addActionListener(java.awt.event.ActionListener)
     Remove Method: public synchronized void Beans01.
        removeActionListener(java.awt.event.ActionListener)
     Event Type: actionPerformed
    */
    printWriter.println("==== Events: ====");
    EventSetDescriptor[] eventSetDescriptor =
                         beanInfo.getEventSetDescriptors();
    for (int i=0; i<eventSetDescriptor.length; i++) {
      printWriter.println("Event Name: " +
                          eventSetDescriptor[i].getName());
      printWriter.println(" Add Method:    " +
             eventSetDescriptor[i].getAddListenerMethod());
      printWriter.println(" Remove Method: " +
          eventSetDescriptor[i].getRemoveListenerMethod());
      MethodDescriptor[] methodDescriptor =
                          eventSetDescriptor[i].
                            getListenerMethodDescriptors();
      for (int j=0; j<methodDescriptor.length; j++) {
          printWriter.println(" Event Type: " +
                            methodDescriptor[j].getName());
      }//end for-loop
    }//end for-loop
    printWriter.println("");

    //A MethodDescriptor describes a particular method that
    // a Java Bean supports for external access from other
    // components.  The getMethodDescriptors() method
    // returns an array of MethodDescriptor objects where
    // each object describes one of the methods.  When this
    // application was applied to the Beans01 bean, the
    // following output was produced by this section
    // of code.
    /*
    ==== Methods: ====
    makeRed
    setMyBooleanProperty
    removeActionListener
    addActionListener
    setColor
    getColor
    getPreferredSize
    makeBlue
    isMyBooleanProperty
    */
    printWriter.println("==== Methods: ====");
    MethodDescriptor[] methodDescriptor =
                           beanInfo.getMethodDescriptors();
    for (int i=0; i<methodDescriptor.length; i++) {
        printWriter.println(methodDescriptor[i].getName());
    }//end for-loop
    printWriter.println("");

    printWriter.close();
  }//end constructor
}//end class Introspect01