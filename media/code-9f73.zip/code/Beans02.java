/*File Beans02.java.java Copyright 1997, R.G.Baldwin
This program was designed to be compiled and executed under JDK 1.1.1.
It was tested using JDK 1.1.1 and the Apr97 version of the BDK 1.0 
under Win95.  

The purpose of this program is to illustrate simple and indexed 
properties.

This bean contains three properties:  a simple Color property named color,
a simple boolean property named ready, and an indexed property named
indexedProperty.

The behavior of the properties were first tested by installing the bean in
the BeanBox and observing the behavior.

The bean contains a method named makeBlue which sets the background color
of the bean by invoking the set method of the color property.  A button was 
installed in the BeanBox along with this bean.  That button was used to 
invoke the makeBlue method which in turn demonstrated the ability to set 
the color property under program control

In addition, it was observed that the color property and the ready property
both appeared in the property editor and behaved as would be expected, both
for setting and getting the values of the properties.

The indexed property did not appear in the property editor of the BeanBox.
I was unable to find anything in the documentation on the BeanBox regarding
the use of the property editor with indexed propertie.

The bean was tested using two other approaches. First, a special test 
program was written which tested the ability to set and get the elements
of the indexed property under program control and also tested the ability
to set and get the entire indexed property array under program control.
The name of that program is Beans02Test.  The results of those tests are
contained in the comments for that program.

Next, an introspection program was applied to the bean to report on its
properties.  The program named Introspect01 is a program developed in an 
earlier lesson that can be used to investigate a bean.  The program applies 
introspection and generates a report on the properties, events, and methods 
of the bean. Application of the Introspect01 program to this bean produced 
the following output (since this bean was developed to illustrate properties,
only that portion of the report dealing with properties is shown).
============================================================================
Name of bean:  Beans02
Class of bean: class Beans02

==== Properties: ====
Name: indexedProperty
 Type:       class [I
 Get method: public synchronized int[] Beans02.getIndexedProperty()
 Set method: public synchronized void Beans02.setIndexedProperty(int[])
Name: preferredSize
 Type:       class java.awt.Dimension
 Get method: public synchronized java.awt.Dimension Beans02.getPreferredSize()
 Set method: null
Name: color
 Type:       class java.awt.Color
 Get method: public synchronized java.awt.Color Beans02.getColor()
 Set method: public synchronized void Beans02.setColor(java.awt.Color)
Name: ready
 Type:       boolean
 Get method: public synchronized boolean Beans02.isReady()
 Set method: public synchronized void Beans02.setReady(boolean)
===========================================================================

The Type specification for the indexed property looks a little strange.
Otherwise, it looks OK insofar as the set and get methods for setting and
getting the entire array of indexed property values.

It is bothersome that the introspector did not also report the set and get
methods for setting and getting a single indexed element for the indexed
property.  To further investigate this, the methods that set and get the
entire indexed property were removed from the program, it was recompiled and
tested again using the introspector.  When this was done, the introspector 
reported the following regarding the indexed property:
===========================================================================
Name: indexedProperty
 Type:       null
 Get method: null
 Set method: null
===========================================================================

This is not what we would hope to see.  The introspector appears to be able 
to recognize the existence of the indexed property, but does not properly 
report on the accessor methods for the individual elements.  I don't know 
if this is a bug in the system or an error in my program.  Again, for the
record, these results were obtained using JDK 1.1.1 and the April 97 version
of BDK 1.0.

Note for the record that the undocumented requirement for a sizeToFit() 
method that existed in the Feb97 version of BDK 1.0 was eliminated in the 
Apr97 version. (See the earlier lesson on the skeleton bean.)

For the record, the batch file used to install this bean in the beanbox 
contained the following:

jar cfm ..\jars\Beans02.jar Beans02.mft sunw\demo\beans02\*.class

The manifest file used in conjunction with the batch file to install the
bean in the beanbox contained the following:

Name: sunw/demo/beans02/Beans02.class
Java-Bean: True

The following package specification was required to install the Bean in 
the BeanBox.  Note that the package specification changes depending on 
where the Bean is installed in the directory structure.
*/
//package sunw.demo.beans02;

import java.awt.event.*;
import java.awt.*;
import java.io.Serializable;
//=========================================================================
public class Beans02 extends Canvas implements Serializable{

  //The following three instance variables are used for properties
  protected Color myColor;
  protected boolean readyPropertyValue = true;
  protected int[] myIndexedInstanceVariable;
  
  public Beans02(){//constructor
    myColor = Color.yellow;//initialize the background color to yellow
    setBackground(myColor);
    //Instantiate an array object to maintain the indexed property
    myIndexedInstanceVariable = new int[3];
  }//end constructor

  //----------------------------------------------------------------------
  //The following "set" and "is" methods in conjunction with the instance
  // variable readyPropertyValue constitute a boolean property named ready.
  // For boolean properties, either a "get" method or an "is" method will
  // support the design pattern requirement.
  public synchronized boolean isReady(){
    return readyPropertyValue;
  }//end isDummyInstanceVariable()
  
  public synchronized void setReady(boolean data){
    readyPropertyValue = data;
  }//end setReady
  
  //----------------------------------------------------------------------
  //The following "set" and "get" methods in conjunction with the instance
  // variable myColor constitute a property of type Color named color.  
  public synchronized void setColor(Color inColor){
    myColor = inColor;
    this.setBackground(myColor);
  }//end setColor()

  public synchronized Color getColor(){
    return myColor;
  }//end getColor

  //---------------------------------------------------------------------
  //The following method is included to demonstrate that the color
  // property can be set under program control by invoking its set access
  // method.
  public synchronized void makeBlue(){
    this.setColor(Color.blue);
  };//end makeBlue()
  //---------------------------------------------------------------------
  
  //The following two methods are intended to satisfy the design pattern 
  // for setting and getting elements from an indexed property.  See the
  // comments at the beginning of the program for a further discussion
  // on this.

  public synchronized int getIndexedProperty(int a){
    return myIndexedInstanceVariable[a];
  }//end getIndexedProperty

  public synchronized void setIndexedProperty(int a, int b){
    myIndexedInstanceVariable[a] = b;  
  }//end setIndexedProperty
  //---------------------------------------------------------------------
  
  //The following two methods satisfy the design pattern for setting and
  // getting the entire array for an indexed property.
  
  public synchronized int[] getIndexedProperty(){
    return myIndexedInstanceVariable;  
  }//end int[] getIndexedProperty()

  public synchronized void setIndexedProperty(int a[]){
    myIndexedInstanceVariable = a;      
  }//
  
  //---------------------------------------------------------------------
  //This method defines the display size of the object when it appears
  // in the BeanBox.  It is called automatically by the layout manager
  // or whatever is controlling the placement and size of components 
  // in the display window.  Note that the Feb97 version of BDK 1.0 did
  // not properly support this approach but the Apr97 version does
  // support it.
  public synchronized Dimension getPreferredSize(){
    return new Dimension(50,50);
  }//end getPreferredSize()
    
}//end class Beans02.java

 