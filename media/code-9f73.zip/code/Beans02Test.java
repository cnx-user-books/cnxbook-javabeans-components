/*File Beans02Test.java.java Copyright 1997, R.G.Baldwin
Revised 10/17/97 to correct some of the comments regarding output.
This program was designed to be compiled and executed under JDK 1.1.1.
The program was tested using JDK 1.1.1 and the Apr97 version of 
BDK 1.0 under Win95.  

This is a minimal test program for Beans02.java.  It is designed to
test only the indexed property of Beans02.  The other properties of
Beans02 can be tested adequately in the BeanBox.

Output from the program is:

Set, get, and display value of 30 in index 2
30
Get, display, and modify entire property array
0
0
30
Using modified array, set, get, and display entire property array
0
1
2
*/

import java.awt.*;
import java.awt.event.*;
//==========================================================
public class Beans02Test extends Frame{
  public static void main(String[] args){
    new Beans02Test();
  }//end main

  public Beans02Test(){//constructor
    setTitle("Copyright 1997, R.G.Baldwin");
    setLayout(new FlowLayout());
    Beans02 myBean = new Beans02();//instantiate a Bean object
    add(myBean);//Add it to the Frame
    setSize(250,200);
    setVisible(true);

    System.out.println("Set, get, and display value of 30 in index 2");    
    myBean.setIndexedProperty(2,30);//store value of 30 in index 2
    System.out.println(myBean.getIndexedProperty(2));//get and display it

    System.out.println("Get, display, and modify entire property array");    
    int[] myArray = myBean.getIndexedProperty();//get the entire property array
    for(int cnt = 0; cnt < myArray.length; cnt++){
      System.out.println(myArray[cnt]); //display it
      myArray[cnt] = cnt;//modify it
    }//end for loop

    System.out.println(
      "Using modified array, set, get, and display entire property array");    
    myBean.setIndexedProperty(myArray);//set property with modified array
    myArray = myBean.getIndexedProperty();//get the entire property array
    for(int cnt = 0; cnt < myArray.length; cnt++)
      System.out.println(myArray[cnt]); //display the modified version
   
    this.addWindowListener(new Terminate());//terminate when Frame is closed    
  }//end constructor
}//end class Beans02Test.java

//==================================================================
class Terminate extends WindowAdapter{
  public void windowClosing(WindowEvent e){
    System.exit(0);//terminate the program when the window is closed  
  }//end windowClosing
}//end class Terminate
//==================================================================